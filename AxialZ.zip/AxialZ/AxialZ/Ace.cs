﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using System.Windows.Forms;
using System.IO;

namespace AxialZ
{
    class Ace
    {
        private void InitializeAce(WebBrowser wb)
        {
            try
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION", true);
                string name = AppDomain.CurrentDomain.FriendlyName;
                if (key.GetValue(name) == null)
                    key.SetValue(name, 11001, RegistryValueKind.DWord);
                key = null;
                name = null;
            }
            catch
            {
            }
            wb.Navigate(Directory.GetCurrentDirectory() + "\\ace\\AceEditor.html");
        }

        public void AddTab(TabControl Tab)
        {
            TabPage page = new TabPage("Script");
            Tab.TabPages.Add(page);
            WebBrowser browser = new WebBrowser();
            browser.Dock = DockStyle.Fill;
            InitializeAce(browser);
            page.Controls.Add(browser);
        }
    }
}